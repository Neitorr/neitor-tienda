document.querySelectorAll('.carousel').forEach(carousel => {
  let index = 0;
  const images = carousel.querySelectorAll('img');
  const showImage = (i) => {
    images.forEach(img => img.classList.remove('active'));
    images[i].classList.add('active');
  };
  carousel.addEventListener('mouseenter', () => {
    carousel._auto = setInterval(() => {
      index = (index + 1) % images.length;
      showImage(index);
    }, 2500);
  });
  carousel.addEventListener('mouseleave', () => {
    clearInterval(carousel._auto);
  });
  carousel.querySelector('.next').onclick = () => {
    index = (index + 1) % images.length;
    showImage(index);
  };
  carousel.querySelector('.prev').onclick = () => {
    index = (index - 1 + images.length) % images.length;
    showImage(index);
  };
});
